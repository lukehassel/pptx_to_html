

# class WordModel(WordEntity):
#     def __init__(self):
#         super().__init__()
#
#     def set_html(self, html):
#         super().set_html(html)
#
#     def get_html(self):
#         return super().get_html()